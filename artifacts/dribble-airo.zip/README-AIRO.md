# Dribble — college basketball coaching sim

Single-player D-I dynasty. This zip is the full game source (no node_modules).

## Run

```
npm install
npm run dev
```

Dev server: http://localhost:8080

Production: `npm run build` then `npm run preview`.

## Stack

React 19, Vite, TanStack Start/Router, Tailwind v4, TypeScript, Zustand.
Saves live in localStorage (`src/game/persist.ts`). No sign-in and no database are required to play.

## Where the game lives

- Engine, rankings, calendar, schedule: `src/game/`
- Screens: `src/components/game/`
- Styles (32-bit UI, scanlines): `src/styles.css`
- Patched Pixelify Sans (digit 5): `src/fonts/`
- School overlay pack: `public/packs/real-schools.json`

See `EXPORT.md` for product rules. Do not rewrite the possession engine, shot math, or schedule generator unless asked.
