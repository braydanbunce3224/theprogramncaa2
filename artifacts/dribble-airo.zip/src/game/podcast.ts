import type { GameResult, GameState, Player, PodcastBeat, PodcastEpisode, PodcastShow, PodcastShowId } from "./types";
import { teamOf } from "./teams";
import { hashString, mulberry32, pick, type Rng } from "./rng";
import { identityName } from "./engine-util";
import { portalOf, portalOpen } from "./portal";
import { assemble, byeBanks, campBanks, gameBanks, marchBanks, offseasonBanks, portalLine, youLine } from "./podcast-lines";

const JARRED = "Jarred";
const BEN = "Ben";
const KALEB = "Kaleb";
const TRILL = "Trill Raff";

export const POD_SHOWS: PodcastShow[] = [
  {
    id: "catican",
    name: "The Catican",
    tagline: "Four friends. They should hang up more.",
    kicker: "Kentucky sports · Unsupervised",
    network: "NoseBleed Boosters",
    homeId: "kentucky",
    hosts: [
      { id: "jarred", name: JARRED },
      { id: "ben", name: BEN },
      { id: "kaleb", name: KALEB },
      { id: "trill", name: TRILL },
    ],
  },
];

const CATICAN_ID = "kentucky";
const RUNTIMES = ["47:19", "51:02", "54:12", "1:02:04", "1:04:33", "1:08:46", "1:10:40", "1:16:21", "1:26:13"];
const TICKER = ["new episode", "they're talking hoops", "Ben watched it back", "Kaleb already has a take", "no merch, please"];

export function showOf(id: PodcastShowId): PodcastShow {
  return POD_SHOWS.find((s) => s.id === id) ?? POD_SHOWS[0]!;
}

export function podcastTicker() {
  return TICKER.join("  ·  ");
}

export function episodesOf(state: GameState, showId?: PodcastShowId): PodcastEpisode[] {
  const all = state.podcasts ?? [];
  if (!showId) return all;
  return all.filter((e) => e.showId === showId);
}

export function podcastTease(state: GameState): { head: string; note: string } {
  const ep = (state.podcasts ?? [])[0];
  if (!ep) return { head: "The Catican", note: "No episode yet. Play a week." };
  const show = showOf(ep.showId);
  return { head: ep.title, note: `${show.name} · ${ep.runtime}` };
}

function catsTeam(state: GameState) {
  return state.teams[CATICAN_ID];
}

function catsCoach(state: GameState) {
  if (state.playerTeamId === CATICAN_ID) return identityName(state.identity);
  const c = catsTeam(state)?.coachName;
  return c && c !== "Staff" ? c : "Staff";
}

function recordOf(state: GameState, id: string) {
  const t = state.teams[id];
  if (!t) return "";
  return `${t.wins}-${t.losses}`;
}

function starOf(state: GameState, teamId: string): Player | null {
  return state.players.filter((p) => p.teamId === teamId && !p.redshirt).sort((a, b) => b.ovr - a.ovr || b.mpg - a.mpg)[0] ?? null;
}

function benchOf(state: GameState, teamId: string): Player | null {
  const rot = state.players.filter((p) => p.teamId === teamId && !p.redshirt).sort((a, b) => b.mpg - a.mpg || b.ovr - a.ovr);
  return rot[4] ?? rot[rot.length - 1] ?? null;
}

function nm(p: Player) {
  return `${p.first} ${p.last}`;
}

function gameThisWeek(state: GameState, teamId: string): GameResult | undefined {
  return [...state.results].reverse().find((r) => r.week === state.week && (r.homeId === teamId || r.awayId === teamId));
}

function won(r: GameResult, teamId: string) {
  return r.homeId === teamId ? r.homeScore > r.awayScore : r.awayScore > r.homeScore;
}

function oppOf(r: GameResult, teamId: string) {
  return r.homeId === teamId ? r.awayId : r.homeId;
}

function scoreLine(r: GameResult, teamId: string) {
  const us = r.homeId === teamId ? r.homeScore : r.awayScore;
  const them = r.homeId === teamId ? r.awayScore : r.homeScore;
  return `${us}-${them}`;
}

function leadName(state: GameState, r: GameResult, teamId: string): { name: string; id: string; pts?: number } | null {
  const rec = r.recap;
  const rows = teamId === r.homeId ? rec?.homeLeaders : rec?.awayLeaders;
  const top = rows?.[0];
  if (top) return { name: top.name, id: top.id, pts: top.pts };
  const p = starOf(state, teamId);
  return p ? { name: nm(p), id: p.id } : null;
}

function catsBox(r: GameResult) {
  const rec = r.recap;
  const home = r.homeId === CATICAN_ID;
  const row = (home ? rec?.homeLeaders : rec?.awayLeaders)?.[0];
  return {
    to: (home ? rec?.homeTo : rec?.awayTo) ?? 0,
    oppTo: (home ? rec?.awayTo : rec?.homeTo) ?? 0,
    orb: (home ? rec?.homeOrb : rec?.awayOrb) ?? 0,
    ppp: (home ? rec?.homePpp : rec?.awayPpp) ?? 0,
    fg: row && row.fga ? `${row.fgm} for ${row.fga}` : "",
    reb: row?.reb ?? 0,
    ast: row?.ast ?? 0,
    ot: (r.minutes ?? 40) > 40,
  };
}

function namesFor(state: GameState, r: GameResult | undefined): PodcastEpisode["names"] {
  const out: NonNullable<PodcastEpisode["names"]> = [];
  const star = starOf(state, CATICAN_ID);
  if (star) out.push({ name: nm(star), id: star.id, kind: "player" });
  const bench = benchOf(state, CATICAN_ID);
  if (bench && bench.id !== star?.id) out.push({ name: nm(bench), id: bench.id, kind: "player" });
  if (r) {
    const lead = leadName(state, r, CATICAN_ID);
    if (lead && !out.some((n) => n.id === lead.id)) out.push({ name: lead.name, id: lead.id, kind: "player" });
  }
  return out.slice(0, 4);
}


function pack(title: string, dek: string, runtime: string, beats: PodcastBeat[], names: PodcastEpisode["names"], resultId?: string) {
  return { title, dek, runtime, beats, names, resultId };
}

function mentionYou(state: GameState): PodcastBeat[] {
  if (state.playerTeamId === CATICAN_ID) return [];
  const played = [...state.results].reverse().find((r) =>
    (r.homeId === CATICAN_ID && r.awayId === state.playerTeamId) || (r.awayId === CATICAN_ID && r.homeId === state.playerTeamId),
  );
  if (!played || played.week !== state.week) return [];
  return [youLine(teamOf(state.playerTeamId).name, won(played, CATICAN_ID))];
}

function makeCatican(state: GameState, rng: Rng): Omit<PodcastEpisode, "id" | "showId" | "week" | "season" | "phase"> {
  const star = starOf(state, CATICAN_ID);
  const bench = benchOf(state, CATICAN_ID);
  const starN = star ? nm(star) : null;
  const benchN = bench && bench.id !== star?.id ? nm(bench) : null;
  const runtime = pick(rng, RUNTIMES);
  const rec = recordOf(state, CATICAN_ID);

  if (state.phase === "offseason") {
    const portal = portalOf(state).transfers.filter((t) => t.fromId === CATICAN_ID || t.committedTo === CATICAN_ID);
    const names = portal.slice(0, 3).map((t) => `${t.first} ${t.last}`);
    return pack(
      pick(rng, ["nobody's playing", "just phones", "is he staying", "offseason"]),
      names.length ? names.join(", ") : "Quiet so far.",
      runtime,
      assemble(rng, offseasonBanks(starN, names)),
      namesFor(state, undefined),
    );
  }

  if (state.phase === "conference" || state.phase === "selection" || state.phase === "ncaa" || state.phase === "nit" || state.phase === "crown") {
    const sel = state.selection;
    const bid = sel?.ncaa?.find((b) => b.teamId === CATICAN_ID);
    const r = gameThisWeek(state, CATICAN_ID);
    const champ = sel?.champ === CATICAN_ID;
    const title = champ
      ? pick(rng, ["they won it", "that's the one", "championship"])
      : bid
        ? pick(rng, [`${bid.seed} seed`, "they're in", `${bid.region}`])
        : pick(rng, ["this week", "selection", "where they landed"]);
    const dek = champ
      ? "They won the tournament."
      : bid
        ? `${bid.seed} seed, ${bid.region}.`
        : r
          ? `${scoreLine(r, CATICAN_ID)}.`
          : "March.";
    return pack(
      title,
      dek,
      runtime,
      assemble(rng, marchBanks({
        champ: Boolean(champ),
        seed: bid?.seed,
        region: bid?.region,
        playIn: bid?.playIn,
        nit: Boolean(sel?.nit?.includes(CATICAN_ID)),
        opp: r ? teamOf(oppOf(r, CATICAN_ID)).name : undefined,
        score: r ? scoreLine(r, CATICAN_ID) : undefined,
        won: r ? won(r, CATICAN_ID) : undefined,
      })),
      namesFor(state, r),
      r?.id,
    );
  }

  const r = gameThisWeek(state, CATICAN_ID);
  if (!r && !state.results.some((x) => x.homeId === CATICAN_ID || x.awayId === CATICAN_ID)) {
    return pack(
      pick(rng, ["camp", "no games yet", "roster talk", "before they tip"]),
      "They haven't played.",
      runtime,
      assemble(rng, campBanks(starN, benchN)),
      namesFor(state, undefined),
    );
  }
  if (!r) {
    return pack(
      pick(rng, ["no game", "bye week", "off this week", "nothing tipped"]),
      rec ? `They're ${rec}. No game.` : "No game.",
      runtime,
      assemble(rng, byeBanks(starN, rec)),
      namesFor(state, undefined),
    );
  }

  const opp = teamOf(oppOf(r, CATICAN_ID)).name;
  const score = scoreLine(r, CATICAN_ID);
  const w = won(r, CATICAN_ID);
  const margin = Math.abs(r.homeScore - r.awayScore);
  const lead = leadName(state, r, CATICAN_ID);
  const box = catsBox(r);
  const where = r.homeId === CATICAN_ID ? "at home" : "on the road";
  const beats = assemble(rng, gameBanks({
    opp,
    score,
    won: w,
    margin,
    where,
    lead: lead?.name ?? null,
    pts: lead?.pts,
    fg: box.fg,
    reb: box.reb,
    to: box.to,
    ot: box.ot,
    rec,
    coach: catsCoach(state),
  }));
  beats.push(...mentionYou(state));
  if (portalOpen(state) && rng() < 0.35) beats.push(portalLine());
  const title = w
    ? margin >= 16
      ? pick(rng, [`handled ${opp}`, `${score}`, "comfortable night"])
      : pick(rng, [`past ${opp}`, `${score}`, "they got it"])
    : margin <= 4
      ? pick(rng, [`${opp}, one possession`, `${score}`, "that one stings"])
      : pick(rng, [`${opp} got them`, `${score}`, "not their night"]);
  return pack(
    title,
    `${score} ${where}.${rec ? ` ${rec}.` : ""}`,
    runtime,
    beats,
    namesFor(state, r),
    r.id,
  );
}

function buildEpisode(state: GameState, show: PodcastShow, rng: Rng): PodcastEpisode {
  const body = show.id === "catican" ? makeCatican(state, rng) : makeCatican(state, rng);
  const week = state.phase === "preseason" ? 0 : state.week;
  return {
    id: `${show.id}-${state.season}-${week}-${state.phase}-${state.results.length}`,
    showId: show.id,
    week,
    season: state.season,
    phase: state.phase,
    ...body,
  };
}

export function tickPodcasts(state: GameState, rng?: Rng): GameState {
  const roll = rng ?? mulberry32(state.seed ^ (state.week * 104729) ^ hashString("pod") ^ state.results.length);
  let list = state.podcasts ?? [];
  for (const show of POD_SHOWS) {
    const ep = buildEpisode(state, show, roll);
    list = [ep, ...list.filter((e) => e.id !== ep.id)];
  }
  return { ...state, podcasts: list.slice(0, 36) };
}

export function hydratePodcasts(raw: GameState["podcasts"]): PodcastEpisode[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter((e) => e && e.id && e.showId && e.title && Array.isArray(e.beats) && e.beats.length);
}
